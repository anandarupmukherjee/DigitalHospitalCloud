document.getElementById('modelSelect').addEventListener('change', function () {
  document.getElementById('downloadForm').submit();
});
